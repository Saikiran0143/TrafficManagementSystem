<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login | SIGNUP</title>
    <!--Meta tags start-->
    <meta charset="UTF-8">
    <meta name="description" content="Smart Traffic Fine Management System for Bangalore">
    <meta name="keywords" content="Traffic, Fine, System, Bangalore">
    <meta name="author" content="VTU">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
    <!--Meta tags end-->
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="../assets/img/logo.png">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../assets/vendors/bootstrap/bootstrap.min.css">
    <!--===============================================================================================-->
    <!-- Import fontawesome from CDN -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <!-- End fontawesome from CDN -->
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../assets/vendors/animatecss/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../assets/css/login.css">
    <!--===============================================================================================-->
</head>

<body>
    <!--Login form start here--->
    <div class="container">
        <div class="row login-section">
            <div class="col-sm-10 col-md-10 col-lg-10 mx-auto">
                <div class="card card-signin my-5">
                    <div class="card-body animated fadeIn">
                        <h1 class="card-icon"><i class="fas fa-car"></i></h1>
                        <h5 class="card-title text-center">User SIGN up</h5>
                        <div class="card mb-3">
                    <div class="card-body p-lg-5">
                    <form action="signup_action" method="POST">
                        
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="vehicle_no">VEHICLE NO</label>

                                <!--If fill this textbox when click submit button this not erase -->
                                <?php if (isset($_GET['vehicle_no'])) { ?>
                                <input type="text"
		                                class="form-control" 
		                                id="vehicle_no"
                                        name="vehicle_no" 
                                        placeholder="Vehicle No"
                                        value="<?php echo $_GET['vehicle_no']; ?>"><br>
                                <?php }else{ ?>
                                        <input type="text" 
		                                class="form-control" 
		                                id="vehicle_no"
                                        name="vehicle_no" 
                                        placeholder="Vehicle No"><br>
                                <?php }?>
                            </div>

                            <div class="form-group col-md-6">
                                <label for="driver_email">USER Email</label>
                                <?php if (isset($_GET['driveremail'])) { ?>
                                <input type="text"
		                                class="form-control" 
		                                id="driver_email"
                                        name="driveremail" 
                                        placeholder="User Email"
                                        value="<?php echo $_GET['driveremail']; ?>"><br>
                                <?php }else{ ?>
                                        <input type="text" 
		                                class="form-control" 
		                                id="driver_email"
                                        name="driveremail" 
                                        placeholder="User Email"><br>
                                <?php }?>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="driver_password">USER Password</label>
                                <input type="password" class="form-control" id="driver_password" name="driverpassword" placeholder="Driver Password">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="driver_password_confirm">Confirm Password</label>
                                <input type="password" class="form-control" id="driver_password_confirm" name="cdriverpassword" placeholder="Confirm Password">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="driver_name">USER Full Name</label>
                                <!-- Already added data get back when click submit button -->
                                <?php if (isset($_GET['drivername'])) { ?>
                                <input type="text"
		                                class="form-control" 
		                                id="driver_name"
                                        name="drivername" 
                                        placeholder="User Full Name"
                                        value="<?php echo $_GET['drivername']; ?>"><br>
                                <?php }else{ ?>
                                        <input type="text" 
		                                class="form-control" 
		                                id="driver_name"
                                        name="drivername" 
                                        placeholder="User Full Name"><br>
                                <?php }?>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="class_of_vehicle">Class of Vehicle</label>
                                <!-- Already added data get back when click submit button -->
                                <?php if (isset($_GET['classofvehicle'])) { ?>
                                <input type="text"
		                                class="form-control" 
		                                id="class_of_vehicle"
                                        name="classofvehicle" 
                                        placeholder="Example: A1, A, B1, B, C1, C,...etc"
                                        value="<?php echo $_GET['classofvehicle']; ?>"><br>
                                <?php }else{ ?>
                                        <input type="text" 
		                                class="form-control" 
		                                id="class_of_vehicle"
                                        name="classofvehicle" 
                                        placeholder="Example: A1, A, B1, B, C1, C,...etc"><br>
                                <?php }?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="home_address">USER Address</label>
                            <!-- Already added data get back when click submit button -->
                            <?php if (isset($_GET['homeaddress'])) { ?>
                                <input type="text"
		                                class="form-control" 
		                                id="home_address"
                                        name="homeaddress" 
                                        placeholder="User Address"
                                        value="<?php echo $_GET['homeaddress']; ?>"><br>
                                <?php }else{ ?>
                                        <input type="text" 
		                                class="form-control" 
		                                id="home_address"
                                        name="homeaddress" 
                                        placeholder="User Address"><br>
                                <?php }?>
                        </div>
                        <div class="form-group col-md-4">
                                <label for="registered_date">Registered Date</label>
                                <input type="date" class="form-control" id="registered_date" name="registereddate" value="<?php echo date("Y-m-d") ?>" disabled>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary"><i class="fas fa-user-plus"></i> SIGN UP</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>




                         <!--===============================================================================================-->
    <script src="../assets/vendors/jquery/jquery-3.5.1.js"></script>
    <!--===============================================================================================-->
    <script src="../assets/vendors/bootstrap/bootstrap.min.js"></script>
    <!--===============================================================================================-->
    <script>
    	//To close the success & error alert with slide up animation
	$("#success-alert").delay(4000).fadeTo(2000, 500).slideUp(1000, function(){
    	$("#success-alert").slideUp(1000);
	});
    </script>
</body>

</html>