<!--Login Action here--->
<?php

session_start();
include "../connection.php";

if (isset($_POST['vehicle_no']) && isset($_POST['driver_password'])) {

	function validate($data){
		$data = trim($data);
		$data = stripcslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}

	$vehicle_no = validate($_POST['vehicle_no']);
	$driver_password = validate($_POST['driver_password']);

	if (empty($vehicle_no)) {
		header("Location: login.php?error=License ID is required!");
		exit();
	}else if (empty($driver_password)) {
		header("Location: login.php?error=Password is required!");
		exit();
		
	}else{
 
		$driver_password = md5($driver_password);

		$sql = "SELECT * FROM driver WHERE vehicle_no='$vehicle_no' AND driver_password='$driver_password'";

		$result = mysqli_query($conn, $sql);

		if (mysqli_num_rows($result) === 1) {
			$row = mysqli_fetch_assoc($result);
			if ($row['vehicle_no'] === $vehicle_no && $row['driver_password'] === $driver_password) {
				$_SESSION['vehicle_no'] = $row['vehicle_no'];
				$_SESSION['driver_name'] = $row['driver_name'];
				$_SESSION['driver_email'] = $row['driver_email'];
				$_SESSION['home_address'] = $row['home_address'];
				header("Location: dashboard.php");
				exit();
				
			}else{
				header("Location: login.php?error= Incorrect License ID or Password!");
				exit();
			}

		}else{
			header("Location: login.php?error= Incorrect License ID or Password!");
			exit();
		} 
	}


}else{
	header("Location: login.php");
	exit();
}



?>