<!--==================================================================================================================================JS_FILES======================================================================================================================================-->
<!-- import script -->
<script type="text/javascript" language="javascript" src="../assets/vendors/chartjs/Chart.min.js"></script>
<script type="text/javascript" language="javascript" src="../assets/js/main.js"></script>
<script type="text/javascript" language="javascript" src="../assets/vendors/jquery/jquery-3.5.1.js"></script>
<script type="text/javascript" language="javascript" src="../assets/vendors/bootstrap/bootstrap.min.js"></script>
<script type="text/javascript" language="javascript" src="../assets/vendors/bootstrap/popper.min.js"></script>



<!--DataTables plugin import start-->
<script type="text/javascript" language="javascript" src="../assets/vendors/DataTables/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript" src="../assets/vendors/DataTables/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript" language="javascript" src="../assets/vendors/DataTables/dataTables.buttons.min.js"></script>
<script type="text/javascript" language="javascript" src="../assets/vendors/DataTables/jszip.min.js"></script>
<script type="text/javascript" language="javascript" src="../assets/vendors/DataTables/pdfmake.min.js"></script>
<script type="text/javascript" language="javascript" src="../assets/vendors/DataTables/vfs_fonts.js"></script>
<script type="text/javascript" language="javascript" src="../assets/vendors/DataTables/buttons.html5.min.js"></script>
<script type="text/javascript" language="javascript" src="../assets/vendors/DataTables/buttons.print.min.js"></script>


<!--Dashboard number counter plugin import start-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js" integrity="sha512-ZKNVEa7gi0Dz4Rq9jXcySgcPiK+5f01CqW+ZoKLINR9VMXuCsw3RjWiv8ZpIOa0hxO79np7Ec8DDWALM0bDOaQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js" integrity="sha512-d8F1J2kyiRowBB/8/pAWsqUl0wSEOkG5KATkVV4slfblq9VRQ6MyDZVxWl2tWd+mPhuCbpTB4M7uU/x9FlgQ9Q==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<!--Boostrap tooltip call script-->
<script>
        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        })
</script>

<!--DataTables plugin import end-->
<!-- end import script -->